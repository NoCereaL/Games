package com.simon;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class End {
    public JLabel titleScreen;
    public JLabel playerOne;
    public JLabel playerTwo;
    public JLabel scoreOne;
    public JLabel scoreTwo;

    public JLayeredPane pane;
    public JFrame frame;

    public JLabel playerOneWon;
    public JLabel playerTwoWon;

    private JLabel background;

    public End(){
        Buttons b = new Buttons();
        frame = new JFrame("Game Over");

        ImageIcon img = new ImageIcon("assets/mons.gif");
        background = new JLabel("",img,JLabel.CENTER);
        background.setSize(1366,768);

        Font winner = new Font("arial", Font.BOLD, 35);
        playerOneWon = new JLabel("Player 1 Wins!!!");
        playerOneWon.setBounds(550,400,2000,50);
        playerOneWon.setFont(winner);
        playerOneWon.setForeground(Color.GREEN);
        playerOneWon.setVisible(false);

        playerTwoWon = new JLabel("Player 2 Wins!!!");
        playerTwoWon.setFont(winner);
        playerTwoWon.setBounds(550,400,2000,50);
        playerTwoWon.setForeground(Color.GREEN);
        playerTwoWon.setVisible(false);

        pane = new JLayeredPane();
        //pane.setBounds(0,0,1366,768);

        Font ti = new Font("arial", Font.BOLD, 30);
        titleScreen = new JLabel("You Defeated the Dungeon!!!");
        titleScreen.setBounds(470,50,2000,50);
        titleScreen.setFont(ti);
        titleScreen.setForeground(Color.red);

        Font player = new Font("arial",Font.BOLD,25);
        playerOne = new JLabel("Player One Achieved:");
        playerOne.setFont(player);
        playerOne.setForeground(Color.BLUE);
        playerOne.setBounds(200,200,2000,50);

        playerTwo = new JLabel("Player Two Achieved:");
        playerTwo.setFont(player);
        playerTwo.setForeground(Color.BLUE);
        playerTwo.setBounds(900,200,2000,50);

        Font score = new Font("arial", Font.BOLD, 20);
        scoreOne = new JLabel("Score: --");
        scoreOne.setForeground(Color.GREEN);
        scoreOne.setFont(score);
        scoreOne.setBounds(280,240,2000,50);
        scoreOne.setVisible(true);

        scoreTwo = new JLabel("Score: --");
        scoreTwo.setForeground(Color.GREEN);
        scoreTwo.setFont(score);
        scoreTwo.setBounds(980,240,2000,50);
        scoreTwo.setVisible(true);

        pane.add(playerOneWon);
        pane.add(playerTwoWon);
        pane.add(b.exit);
        pane.add(b.playAgain);
        pane.add(titleScreen);
        pane.add(playerOne);
        pane.add(playerTwo);
        pane.add(scoreOne);
        pane.add(scoreTwo);
        pane.add(background);

        frame.add(pane);
        frame.setSize(1368,768);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        Scores s = new Scores();

        if (s.score > s.score2){
            playerOneWon.setVisible(true);
        }
        if (s.score2 > s.score){
            playerTwoWon.setVisible(true);
        }

        b.playAgain.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
                String[] args = new String[2];
                Launcher.main(args);
            }
        });
        b.exit.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
    }
}
package com.simon;

import javax.swing.*;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;

/**
 * This class is the entry point for the project, containing the main method that
 * starts a game. It creates instances of the different classes of this project
 * and connects them appropriately.
 * @author prtrundl
 */
public class Launcher {

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {

            /**
             * The run method starts the game in a separate thread. It creates
             * the GUI, the engine and the input handler classes and connects
             * those that call other objects.
             */
            @Override
            public void run() {
                new Menu();
            }
        });

    }

}

